package university;

import java.util.Dictionary;

public class Student {
	/*
	 * instance variables
	 */
	String name;
	int graduationYear;
	double GPA;
	int numCoursesCompleted;
	boolean inGoodStanding;
	TA recitationTA;
	double numericValue;
	String numCoursesString;
	/*
	 * initialize variables
	 */
	public Student(String studentName, int graduationYear){
		this.name = studentName;
		this.graduationYear = graduationYear;
		this.GPA = 0;
		this.numCoursesCompleted = 0;
		this.inGoodStanding = true;
		this.recitationTA = null;
	}
	/*
	 * return student's name
	 */
	public String getName(){
		return this.name;
	}
	/*
	 * return student's graduation year
	 */
	public int getGraduationYear(){
		return this.graduationYear;
	}
	/*
	 * change student's graduation year
	 */
	public void setGraduationYear(int year){
		this.graduationYear = year;
	}
	/*
	 * return student's GPA
	 */
	public double getGPA(){
		return this.GPA;
	}
	/*
	 * see if the student is eligible for dean list according to the GPA and
	 * if in good standing
	 */
	public boolean isEligibleForDeanList(){
		if( this.GPA > 3.7 & this.inGoodStanding){
			return true;
		}
		else{
			return false;
		}
	}
	/*
	 * print the course the student enrolled
	 */
	public void takeCourse(String courseName){
		System.out.println(this.name + " is now enrolled in " + courseName);
	}
	/*
	 * calculate general GPA for student and number of courses taken
	 */
	public void recieveGrade(String courseName, String grade){
		System.out.println(this.name + " got " + grade + " in " + courseName);
		if(grade == "A"){
			numericValue = 4;
		}
		else if(grade == "A-"){
			numericValue = 3.7;
		}
		else if(grade == "B+"){
			numericValue = 3.3;
		}
		else if(grade == "B"){
			numericValue = 3;
		}
		else if(grade == "B-"){
			numericValue = 2.7;
		}
		else if(grade == "C+"){
			numericValue = 2.3;
		}
		else if(grade == "C"){
			numericValue = 2;
		}
		else if(grade == "C-"){
			numericValue = 1.3;
		}
		else if(grade == "D+"){
			numericValue = 1.0;
		}
		this.GPA = (this.GPA * this.numCoursesCompleted + numericValue) / (this.numCoursesCompleted + 1);
		this.numCoursesCompleted += 1;
	}
	/*
	 * student has cheated not in good standing
	 */
	public void caughtCheating(){
		this.inGoodStanding = false;
	}
	/*
	 * print the general info of the student
	 */
	public void printReport(){
		System.out.println("This is " + this.name + " UPENN " + this.graduationYear);
		System.out.println("Their GPA is " + this.GPA);
		if ( this.numCoursesCompleted == 1){
			numCoursesString = "course";
		}
		else{
			numCoursesString = "courses";
		}
		System.out.println("They have taken " + this.numCoursesCompleted + " " + numCoursesString);
	}
	/*
	 * assign the TA and get the recitation time of TA for student
	 */
	public void assignRecitationTA(TA TA){
		this.recitationTA = TA;
		System.out.println(this.name + " your TA is " + TA.getName() + " whose recitation is at " + TA.getRecitationTime());		
	}
	
}
