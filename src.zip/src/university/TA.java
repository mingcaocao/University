package university;

public class TA {
	// instance variables
	String name;
	String course;
	String officeHourDay;
	int officeHourTime;
	int recitationTime;
	/*
	 * initialize variables
	 */
	public TA(String taName, String courseName){
		this.name = taName;
		this.course = courseName;
		this.officeHourDay = "unknown";
		this.officeHourTime = 0;
		this.recitationTime = 0;
	}
	/*
	 * set the office hour for TA
	 */
	public void pickOfficeHours(String day, int start){
		this.officeHourDay = day;
		this.officeHourTime = start;
	}
	/*
	 * set the recitation time for TA
	 */
	public void pickRecitationTime(int start){
		this.recitationTime = start;
	}
	/*
	 * get TA's name
	 */
	public String getName(){
		return this.name;
	}
	/*
	 * get TA's recitation time
	 */
	public int getRecitationTime(){
		return this.recitationTime;
	}
	//print TA's office hour
	public void displayOfficeHours(){
		System.out.println("office hours " + this.officeHourDay + " from " + (this.officeHourTime) + " to " + (this.officeHourTime + 2));
	}
	// grade student
	public void gradeStudent(Student student, String grade){
		student.recieveGrade(this.course, grade);
	}
	
}
